 <header>
       
        <span>مهمتك </span>
        </header>
        <nav>
        <h1>لوحة التحكم</h1>
            <ul>
                <li><a href="dashboard.php">الرئيسية</a></li>
                <li><a href="admin_profile.php">الملف الشخصي</a></li>
                <li><a href="task.php">اضافة المهام</a></li>
                <li><a href="teacher.php">اضافة استاذ</a></li>
                <li><a href="taskcom.php">توزيع المهام </a></li>
                <li><a href="logout.php">تسجيل الخروج</a></li>
            </ul>
        </nav>